# Hotel-Project
This is a Hotel website. I have designed this website by using HTML &amp; CSS. My text editor is V.S code and i hope you like this project.
